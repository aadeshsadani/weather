// import { Cards } from '@mui/material';
import './App.css';
import { StyledEngineProvider, CssVarsProvider } from '@mui/joy/styles';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import Cards from './components/Cards';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import { useEffect } from 'react';
function App() {
  const userToken = localStorage.getItem('token');
  useEffect(()=>{
    if(userToken){
      console.log(userToken)
    }
  },[])
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Cards />}/>
          <Route path='/signin' element={<SignIn />}/>
          <Route path='/dashboard' element={<Dashboard />}/>
          <Route path='/signup' element={<SignUp />}/> 
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
