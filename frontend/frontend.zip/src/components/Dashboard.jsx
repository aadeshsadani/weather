const Dashboard = () => {
    return(
        <>
            <h1>Hello From Dashboard</h1>   
        </>
    )
}

export default Dashboard