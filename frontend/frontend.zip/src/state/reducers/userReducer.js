import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import axios from 'axios';
export const userLogin = createAsyncThunk('login/userLogin', async (data) => {
    const options = {
        method : 'POST',
        headers : {
            'Content-Type' : 'application/json'
        },
        body : JSON.stringify(data)
    }
    try {
        const userData = await fetch('http://localhost:2929/login',options);
        return userData.json();
    } catch (error) {
        return error
    }
});

const user = createSlice({
    name : 'login',
    initialState: {
        register : {
            value : 'empty',
            status : 'idle',
            error : null,
            messahe : ''
        }
    },
    reducers : {},
    extraReducers : (builder) => {
        builder
            .addCase(userLogin.pending, (state,action)=>{
                state.register.status = 'pending'
            })
            .addCase(userLogin.fulfilled, (state, action) =>{
                state.register.status = 'succeeded';
                if(!action.payload.error){
                    alert('user Loggedin');

                }else{
                    alert(`${action.payload.error}`)
                }
            })
            .addCase(userLogin.rejected, (state, action) => {
                state.register.status = 'rejected';
                state.register.error = action.payload
            });
    }    
});
export default  user.reducer